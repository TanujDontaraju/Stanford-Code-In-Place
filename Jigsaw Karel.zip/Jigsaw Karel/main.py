from karel.stanfordkarel import *


# Main Function 
def main():
    initial_pick_up()
    set_beeper()
    return_to_start()

# 3 other / sub functions created 
#(initial_pick_up, set_beeper, and to_start) 
# Easily shows the 3 big steps to solving this problem 

# (1) Function to initially pick up the beeper   
def initial_pick_up():
    move()
    move()
    pick_beeper()  

# (2) Function to place beeper in the intended spot
def set_beeper():
    move()
    turn_left()
    move()
    move()
    put_beeper()

# (3) Function to move Karel back to starting position
def return_to_start():
    turn_left()
    turn_left()
    move()
    move()
    turn_right()
    move()
    move()
    move()
    turn_left()
    turn_left()

# Function to turn right as turning left 3x = 1x turn right 
# Less lines are also used for cleaner look
def turn_right():
    turn_left()
    turn_left()
    turn_left()


# There is no need to edit code beyond this point
if __name__ == '__main__':
    main()